<?php 
session_start();
include('condb.php'); 
if(!isset($_SESSION['username'])){
    header("location: login.php");
}
$sql="select COUNT(order_id) AS order_no from tb_order where order_status='1' ";
$hand=mysqli_query($conn,$sql);
$row=mysqli_fetch_array($hand);

$sql1="select COUNT(order_id) AS order_yes from tb_order where order_status='2' ";
$hand1=mysqli_query($conn,$sql1);
$row1=mysqli_fetch_array($hand1);

$sql2="select COUNT(order_id) AS order_cancel from tb_order where order_status='0' ";
$hand2=mysqli_query($conn,$sql2);
$row2=mysqli_fetch_array($hand2);
//ของต่ำกว่า5ชิ้น
$sql3="select COUNT(pro_id) AS pro_num from product where amount < 5 ";
$hand3=mysqli_query($conn,$sql3);
$row3=mysqli_fetch_array($hand3);

?>

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Dashboard - SB Admin</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    </head>
    <body class="sb-nav-fixed">
            <?php include 'adminmenu.php';?>

            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">รายงานล่าสุด</h1>
                        <ol class="breadcrumb mb-4">
                            <a href="../index_logout.php"><button type="button" class="btn btn-outline-success">กลับหน้าเว็บไซต์</button></a>
                        </ol>
                        <div class="row">
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-primary text-white mb-4">
                                    <div class="card-body">รายการสั่งซื้อสินค้า(ยังไม่ชำระเงิน) <h4>[<?=$row['order_no']?>]</h4></div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="small text-white stretched-link" href="report_order.php">ดูรายละเอียดเพิ่มเติม</a>
                                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-warning text-white mb-4">
                                    <div class="card-body">สินค้าที่ต่ำกว่า 5 ชิ้น<h4>[<?=$row3['pro_num']?>]</h4></div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="small text-white stretched-link" href="pro_stop.php">ดูรายละเอียดเพิ่มเติม</a>
                                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-success text-white mb-4">
                                    <div class="card-body">ชำระเงินเรียบร้อย<h4>[<?=$row1['order_yes']?>]</h4></div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="small text-white stretched-link" href="report_order_yes.php">ดูรายละเอียดเพิ่มเติม</a>
                                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-danger text-white mb-4">
                                    <div class="card-body">รายการสั่งซื้อที่ยกเลิก<h4>[<?=$row2['order_cancel']?>]</h4></div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="small text-white stretched-link" href="report_order_no.php">ดูรายละเอียดเพิ่มเติม</a>
                                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                       

                        <div class="card mb-4">
                            <div class="card-header">
                                <i class="fas fa-table me-1"></i>
                                DataTable Example
                            </div>
                            <div class="card-body">
                                <table id="datatablesSimple">
                                <thead>
                                        <tr>
                                            <th>เลขที่ใบสั่งซื้อ</th>
                                            <th>ชื่อ-นามสกุล</th>
                                            <th>ที่อยู่</th>
                                            <th>เบอร์โทรศัพท์</th>
                                            <th>ราคาที่ต้องชำระ</th>
                                            <th>วันที่สั่งซื้อ</th>
                                            <th>สถานะการสั่งซื้อ</th>
                                            <th>ดูใบสั่งซื้อ</th>
                                            <th>ปรับรายการ</th>
                                            <th>ยกเลิกรายการ</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                            <th>orderid</th>
                                            <th>us_name</th>
                                            <th>address</th>
                                            <th>telephone</th>
                                        </tr>
                                    </tfoot>
                                    <?php 
                                    $sql = "SELECT * FROM tb_order  ORDER BY order_date DESC";
                                    $result = mysqli_query($conn, $sql);
                                    ?>
                                    
                                    <tbody>
                                    <?php while($row = mysqli_fetch_array($result)): ?>
                                    <?php 
                                    $status = $row['order_status'];
                                    ?>
                                    <tr>
                                        <td><?=$row['order_id']?></td>
                                        <td><?=$row['us_name']?></td>
                                        <td><?=$row['address']?></td>
                                        <td><?=$row['telephone']?></td>
                                        <td><?= number_format($row['total_price'], 2) ?></td>
                                        <td><?=$row['order_date']?></td>
                                        <td>
                                            <?php 
                                            if($status == 0){
                                                echo '<span style="color: red;">ยกเลิกรายการ</span>';
                                            }else if($status == 1){
                                                echo'<span style="color: orange;">ยังไม่ได้ชำระเงิน</span>';
                                            }else if($status == 2){
                                                echo'<span style="color: green;">ชำระเงินแล้ว</span>';
                                            }
                                            ?>
                                        </td>
                                            <td>
                                            <a class="btn btn-outline-danger bi bi-receipt-cutoff" href="report_order_detail.php?id=<?=$row['order_id']?>" role="button"></a>
                                            </td>
                                            <td>
                                            <a class="btn btn-outline-danger bi bi-pen" onclick="del1(this.href); return false;" href="pay_order.php?id=<?=$row['order_id']?>" role="button"></a>
                                            </td>
                                            <td>
                                            <a class="btn btn-outline-danger bi bi-x-lg" onclick="del(this.href); return false;" href="cancel_order.php?id=<?=$row['order_id']?>" role="button"></a>
                                            </td>
                                    </tr>
                                <?php endwhile; ?>
                                    </tbody>
                                    <?php
                                    mysqli_close($conn); 
                                    ?>
                                </table>
                            </div>
                        </div>
                    </div>
                </main>
                <?php include 'footer.php';?>
            </div>
        </div>
    </body>
</html>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="assets/demo/chart-area-demo.js"></script>
        <script src="assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
        <script>function del(mypage){
            var agree = confirm('คุณต้องการยกเลิกรายการใช่หรือไม่');
            if(agree){
                window.location=mypage;
            }
        }
        </script>
