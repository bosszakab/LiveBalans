<?php include 'condb.php'; ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Dashboard - SB Admin</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    </head>
    <body class="sb-nav-fixed">
            <?php include 'adminmenu.php';?>

            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        
                        <div class="card mb-4 mt-4">
                            <div class="card-header">
                                <i class="fas fa-table me-3 mt-3"></i>
                                รายงานแสดงการสั่งซื้อสินค้าที่ชำระเงินเรียบร้อย
                                <div class="mt-3">
                                <a href="report_order_yes.php"><button type="button" class="btn btn-outline-success">ชำระเงินแล้ว</button></a> |
                                <a href="report_order.php"><button type="button" class="btn btn-outline-danger">ยังไม่ได้ชำระเงิน</button></a> |
                                <a href="report_order_no.php"><button type="button" class="btn btn-outline-success">ยกเลิกรายการสั่งซื้อ</button></a>
                                </div>
                            </div>
                            <div class="card-body">
                                <table id="datatablesSimple">
                                    <thead>
                                        <tr>
                                            <th>เลขที่ใบสั่งซื้อ</th>
                                            <th>ชื่อ-นามสกุล</th>
                                            <th>ที่อยู่</th>
                                            <th>เบอร์โทรศัพท์</th>
                                            <th>ราคาที่ต้องชำระ</th>
                                            <th>วันที่สั่งซื้อ</th>
                                            <th>สถานะการสั่งซื้อ</th>
                                            <th>ยกเลิกรายการ</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                            <th>orderid</th>
                                            <th>us_name</th>
                                            <th>address</th>
                                            <th>telephone</th>
                                        </tr>
                                    </tfoot>
                                    <?php 
                                    $sql = "SELECT * FROM tb_order where order_status='2' ORDER BY order_date DESC";
                                    $result = mysqli_query($conn, $sql);
                                    ?>
                                    
                                    <tbody>
                                    <?php while($row = mysqli_fetch_array($result)): ?>
                                    <?php 
                                    $status = $row['order_status'];
                                    ?>
                                    <tr>
                                        <td><?=$row['order_id']?></td>
                                        <td><?=$row['us_name']?></td>
                                        <td><?=$row['address']?></td>
                                        <td><?=$row['telephone']?></td>
                                        <td><?= number_format($row['total_price'], 2) ?></td>
                                        <td><?=$row['order_date']?></td>
                                        <td>
                                            <?php 
                                            if($status == 0){
                                                echo '<span style="color: red;">ยกเลิกรายการ</span>';
                                            }else if($status == 1){
                                                echo'<span style="color: orange;">ยังไม่ได้ชำระเงิน</span>';
                                            }else if($status == 2){
                                                echo'<span style="color: green;">ชำระเงินแล้ว</span>';
                                            }
                                            ?>
                                        </td>
        
                                            <td>
                                            <a class="btn btn-outline-danger bi bi-x-lg" onclick="del(this.href); return false;" href="cancel_order.php?id=<?=$row['order_id']?>" role="button"></a>
                                            </td>
                                    </tr>
                                <?php endwhile; ?>
                                    </tbody>
                                    <?php
                                    mysqli_close($conn); 
                                    ?>
                                </table>
                            </div>
                        </div>
                    </div>
                </main>
                <?php include 'footer.php';?>
            </div>
        </div>
    </body>
</html>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="assets/demo/chart-area-demo.js"></script>
        <script src="assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
        <script>function del(mypage){
            var agree = confirm('คุณต้องการยกเลิกรายการสั่งซื้อใช่หรือไม่');
            if(agree){
                window.location=mypage;
            }
        }
        </script>
