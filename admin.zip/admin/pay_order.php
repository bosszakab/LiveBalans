<?php 
include 'condb.php';
$id=$_GET['id'];
$sql="UPDATE tb_order set order_status = 2 where order_id='$id' ";
$result=mysqli_query($conn,$sql);
if($result){
    echo"<script> alert('ปรับรายการเป็นชำระเงินเรียบร้อย'); </script>";
    echo"<script> window.location='report_order.php' </script>";
}else{
    echo"<script> alert('ไม่สามารถรับข้อมูลได้'); </script>";
}
mysqli_close($conn);
?>  