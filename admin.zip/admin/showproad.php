<?php include 'condb.php'; ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Dashboard - SB Admin</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    </head> <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
        
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    <body class="sb-nav-fixed">
            <?php include 'adminmenu.php';?>

            <div id="layoutSidenav_content">
                <main>
                <div class="container">
        <div class="alert alert-primary h3 text-center" role="alert">
                ข้อมูลสินค้าคงเหลือ
         </div>
         <a class="btn btn-outline-success mb-3" href="../showproduct.php" role="button">ไปหน้าแก้ไขข้อมูลสินค้า</a>
            <table class="table table-bordered border-primary">
            <tr>
                <th>รูปภาพสินค้า</th>
                <th>รหัสสินค้า</th>
                <th>ชื่อสินค้า</th>
                <th>ประเภทสินค้า</th>
                <th>ราคา</th>
                <th>จำนวน</th>
              

            </tr>
            <?php 
                $sql="SELECT * FROM product,type where product.type_id = type.type_id";
                $hand = mysqli_query($conn,$sql);
                while($row=mysqli_fetch_array($hand)){

                
            ?>
            <tr>
                <td><img src="../image/<?=$row['image']?> "width="150" hieght="100" class="rounded mx-auto d-block"></td>
                <td ><?=$row['pro_id']?></td>
                <td ><?=$row['pro_name']?></td>
                <td ><?=$row['type_name']?></td>
                <td class="text-end"><?= number_format($row['price'], 2) ?></td>
                <td class="text-end"><?=$row['amount']?></td>
            </tr>
            <?php 
                 }
                 mysqli_close($conn);
            ?>
        </table>
    </div>
    </body>
</html>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="assets/demo/chart-area-demo.js"></script>
        <script src="assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
        <script>function del(mypage){
            var agree = confirm('คุณต้องการยกเลิกรายการสั่งซื้อใช่หรือไม่');
            if(agree){
                window.location=mypage;
            }
        }function del1(mypage1){
            var agree = confirm('คุณต้องการปรับรายการเป็นชำระเงินแล้วใช่หรือไม่');
            if(agree){
                window.location=mypage;
            }
        }
        </script>
